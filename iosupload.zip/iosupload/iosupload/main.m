//
//  main.m
//  iosupload
//
//  Created by upin on 13-1-23.
//  Copyright (c) 2013年 linggan. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LKAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LKAppDelegate class]));
    }
}
