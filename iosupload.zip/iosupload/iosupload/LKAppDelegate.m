//
//  LKAppDelegate.m
//  iosupload
//
//  Created by upin on 13-1-23.
//  Copyright (c) 2013年 linggan. All rights reserved.
//

#import "LKAppDelegate.h"
#import "ASIFormDataRequest.h"
#import "MKNetworkKit.h"
@implementation LKAppDelegate

- (void)dealloc
{
    [_window release];
    [super dealloc];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    
    NSString* path =  [[NSBundle mainBundle] pathForResource:@"iphone1-1-10" ofType:@"png"];
#pragma mark 使用ASIHttpRequest 上传图片和数据
   ASIFormDataRequest* request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:@"http://192.168.0.1/IOSUPLOAD/WebForm1.aspx"]];
    [request addFile:path forKey:@"img"];
    [request addPostValue:@"asihttp" forKey:@"name"];
    [request setCompletionBlock:^{
        NSLog(@"%@",request.responseString);
    }];
    [request setFailedBlock:^{
            NSLog(@"asi error: %@",request.error.debugDescription);
    }];
    [request startAsynchronous];
    
#pragma mark 使用MKNetworkKit 上传图片和数据
    MKNetworkEngine* engine = [[[MKNetworkEngine alloc] init] autorelease];
    NSDictionary* postvalues = [NSDictionary dictionaryWithObjectsAndKeys:@"mknetwork",@"name",nil];
   MKNetworkOperation* op = [engine operationWithURLString:@"http://192.168.0.1/IOSUPLOAD/WebForm1.aspx" params:postvalues httpMethod:@"POST"];
    [op addFile:path forKey:@"img"];
    [op addCompletionHandler:^(MKNetworkOperation *completedOperation) {
        NSLog(@"%@",request.responseString);
    } errorHandler:^(MKNetworkOperation *completedOperation, NSError *error) {
            NSLog(@"mknetwork error : %@",error.debugDescription);
    }];
    [engine enqueueOperation:op];

    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
