﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RemoteImage
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Files.Count == 0)
            {
                Response.Write("none file");
            }
            else
            {
                HttpPostedFile file = Request.Files["img"];
                String filename = Request.Form["name"];
                file.SaveAs(MapPath("~/" + filename + ".png"));

                Response.Write("ok");
            }

        }
    }
}